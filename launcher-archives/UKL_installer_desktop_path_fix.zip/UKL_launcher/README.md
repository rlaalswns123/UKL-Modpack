# UKL 런처 1차 버전

UKL 독립 런처의 1단계 버전입니다. 기본 화면, 최초 실행 마법사, Java 17·21 자동 탐색, RAM·화면 크기 설정을 포함합니다.

## 현재 포함된 기능

- Java 17·21 자동 탐색
- Java 설치 경로 표시
- RAM 할당량 설정 저장
- 화면 너비·높이 설정 저장
- 게임 폴더 설정
- 업데이트 manifest URL 확인
- ZIP 형태 모드팩 업데이트
- `mods`, `config`, `defaultconfigs`를 포함한 업데이트 ZIP 적용
- 설정과 버전 파일 보존
- 최초 실행 마법사
- 독립 런처 UI 기반
- 설정을 Windows AppData에 영구 저장

## 중요한 제한

이 1단계 버전은 아직 Microsoft 계정 인증, 모드팩 다운로드, Minecraft 직접 실행을 구현하지 않았습니다. 다음 단계에서 공식 인증과 게임 실행 모듈을 추가합니다.

## Windows에서 빌드하기

Windows PC에서 Python 3.11 이상을 설치한 뒤 이 폴더에서 `build_windows.bat` 또는 `build_installers.bat`를 실행합니다. 결과물은 `dist\UKL_Setup.exe`입니다.

친구들에게는 **`UKL_Setup.exe` 하나만** 전달하면 됩니다. 친구가 이 파일을 실행하면 `AppData\Local\UKL`에 UKL을 설치하고 바탕화면에 `UKL` 바로가기를 만든 뒤 런처를 실행합니다.

## 첫 설정

1. Windows에서 `build_windows.bat`를 실행합니다.
2. 생성된 `dist\UKL_Setup.exe`를 실행합니다.
3. 설치가 끝나면 자동으로 실행되는 UKL에서 최초 실행 마법사를 진행합니다.
4. 기본 화면의 **게임 시작**은 다음 단계 구현 전까지 안내 메시지를 표시합니다.

설정은 실행 파일 내부나 임시 폴더가 아니라 다음 위치에 저장됩니다.

```text
C:\Users\사용자이름\AppData\Roaming\UKL\launcher_config.json
```

## 업데이트 파일 구조

manifest 예시:

```json
{
  "version": "1.0.1",
  "minecraft": "1.20.1",
  "loader": "forge",
  "download": "https://example.com/client-1.0.1.zip"
}
```

ZIP 내부는 다음처럼 구성합니다.

```text
mods/
config/
defaultconfigs/
```

런처는 업데이트 ZIP을 게임 폴더에 안전하게 압축 해제합니다. `saves`, `screenshots`, `options.txt`, `servers.dat`는 ZIP에 넣지 않아 기존 사용자 데이터를 보존하세요.

## 설치 위치

```text
C:\Users\사용자이름\AppData\Local\UKL\
└─ UKL.exe
```

## 참고

Prism Launcher의 실제 실행 인자나 설치 위치는 버전에 따라 다를 수 있습니다. 실행이 되지 않으면 설정에서 Prism Launcher 경로와 인스턴스 이름을 확인하세요.

## 나중에 추가할 기능: 런처 이미지

배경, UKL 로고, 프로필 아이콘, 디스코드 아이콘 등의 이미지는 추후 `assets` 폴더에 넣고 런처 UI에 연결할 수 있습니다. Windows 빌드 시 PyInstaller의 `--add-data "assets;assets"` 옵션을 사용하며, 실행 파일 내부의 이미지 경로를 처리하는 리소스 경로 코드가 필요합니다.
