@echo off
call build_installers.bat
