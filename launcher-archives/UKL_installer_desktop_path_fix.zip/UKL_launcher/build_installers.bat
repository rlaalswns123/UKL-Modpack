@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title UKL Builder

echo ========================================
echo UKL installer build
 echo Working folder: %CD%
echo ========================================
echo.

where python >nul 2>&1
if errorlevel 1 goto NO_PYTHON
python --version
if errorlevel 1 goto NO_PYTHON

echo [1/4] Installing PyInstaller...
python -m pip install --upgrade pyinstaller
if errorlevel 1 goto FAIL

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist payload rmdir /s /q payload
mkdir payload

echo [2/4] Building UKL.exe...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name UKL launcher_v2.py
if errorlevel 1 goto FAIL
if not exist dist\UKL.exe goto FAIL
copy /y dist\UKL.exe payload\UKL.exe >nul
copy /y launcher_config.json payload\launcher_config.json >nul

echo [3/4] Building UKL_Setup.exe...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name UKL_Setup --add-binary "payload\UKL.exe;payload" --add-data "payload\launcher_config.json;payload" installer.py
if errorlevel 1 goto FAIL
if not exist dist\UKL_Setup.exe goto FAIL

echo [4/4] BUILD COMPLETE
echo.
echo Send this file to your friends:
echo %CD%\dist\UKL_Setup.exe
goto DONE

:NO_PYTHON
echo ERROR: Python was not found.
echo Install Python 3.11 or newer and enable Add Python to PATH.
goto FAIL

:FAIL
echo.
echo BUILD FAILED. Read the error messages above.

:DONE
echo.
pause
endlocal
