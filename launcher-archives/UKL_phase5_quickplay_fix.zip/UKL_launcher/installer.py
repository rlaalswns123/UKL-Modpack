import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

APP_NAME = "UKL"
INSTALL_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home())) / APP_NAME


def resource_root():
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS) / "payload"
    return Path(__file__).resolve().parent / "payload"


def create_shortcut(target):
    target = Path(target).resolve()
    # Desktop 리디렉션/OneDrive/한국어 Windows 설정을 포함한 실제 바탕화면 경로를 사용합니다.
    desktop_expr = "[Environment]::GetFolderPath('Desktop')"
    script = (
        f"$desktop = {desktop_expr}; "
        f"New-Item -ItemType Directory -Force -Path $desktop | Out-Null; "
        f"$old = Join-Path $desktop 'UKL.exe'; if (Test-Path $old) {{ Remove-Item $old -Force -ErrorAction SilentlyContinue }}; "
        f"$shortcut = Join-Path $desktop 'UKL.lnk'; "
        "$ws = New-Object -ComObject WScript.Shell; "
        "$sc = $ws.CreateShortcut($shortcut); "
        f"$sc.TargetPath = '{target}'; "
        f"$sc.WorkingDirectory = '{target.parent}'; "
        f"$sc.IconLocation = '{target}'; "
        "$sc.Description = 'UKL 런처'; $sc.Save(); "
        "Write-Output $shortcut"
    )
    result = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], check=False, capture_output=True, text=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if result.returncode != 0:
        raise RuntimeError(f"바탕화면 바로가기를 만들지 못했습니다: {result.stderr.strip() or 'PowerShell 오류'}")


def install():
    payload = resource_root()
    launcher = payload / "UKL.exe"
    if not launcher.exists():
        raise RuntimeError("설치 파일 내부에서 UKL 런처를 찾지 못했습니다.")
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    # 기존 런처가 실행 중이면 UKL.exe가 잠겨 새 파일로 교체할 수 없습니다.
    subprocess.run(["taskkill", "/F", "/IM", "UKL.exe"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    installed_launcher = INSTALL_DIR / "UKL.exe"
    last_error = None
    for _ in range(10):
        try:
            shutil.copy2(launcher, installed_launcher)
            last_error = None
            break
        except PermissionError as error:
            last_error = error
            time.sleep(0.5)
    if last_error is not None:
        raise RuntimeError(f"기존 UKL.exe가 사용 중이어서 설치할 수 없습니다. UKL을 완전히 종료한 뒤 다시 실행하세요.\n\n상세 오류: {last_error}")
    config = payload / "launcher_config.json"
    if config.exists() and not (INSTALL_DIR / "launcher_config.json").exists():
        shutil.copy2(config, INSTALL_DIR / "launcher_config.json")
    create_shortcut(INSTALL_DIR / "UKL.exe")
    subprocess.Popen([str(INSTALL_DIR / "UKL.exe")], cwd=str(INSTALL_DIR))


if __name__ == "__main__":
    try:
        install()
    except Exception as error:
        root = tk.Tk(); root.withdraw()
        messagebox.showerror("UKL 설치 실패", str(error))
        root.destroy()
        raise
