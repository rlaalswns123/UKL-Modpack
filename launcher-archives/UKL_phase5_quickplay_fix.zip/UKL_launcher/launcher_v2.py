import json
import base64
import hashlib
import os
import re
import secrets
import subprocess
import sys
import threading
import uuid
import urllib.parse
import urllib.error
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
import tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox, filedialog

ROOT = Path(__file__).resolve().parent
# PyInstaller --onefile 실행 시 __file__은 임시 폴더를 가리킬 수 있으므로,
# 사용자 설정은 항상 영구적인 Windows AppData 위치에 저장합니다.
if getattr(sys, "frozen", False):
    CONFIG_DIR = Path(os.environ.get("APPDATA", Path.home())) / "UKL"
else:
    CONFIG_DIR = ROOT
CONFIG_DIR.mkdir(parents=True, exist_ok=True)
CONFIG_PATH = CONFIG_DIR / "launcher_config.json"
TOKEN_PATH = CONFIG_DIR / "auth_tokens.json"
DEFAULT_CONFIG = {"manifest_url": "", "game_dir": str(CONFIG_DIR / "MinecraftClient"), "ram_gb": 6, "width": 1280, "height": 720, "minecraft_version": "1.20.1", "loader": "forge", "loader_version": "", "version": "0.0.0", "setup_complete": False, "selected_java": "", "microsoft_client_id": "", "microsoft_signed_in": False, "server_address": "127.0.0.1:25565"}


def load_config():
    data = DEFAULT_CONFIG.copy()
    if CONFIG_PATH.exists():
        try:
            data.update(json.loads(CONFIG_PATH.read_text(encoding="utf-8")))
        except Exception:
            pass
    return data


def save_config(data):
    CONFIG_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def find_java():
    roots = [Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / name for name in ("Java", "Eclipse Adoptium", "Microsoft", "Amazon Corretto", "BellSoft")]
    env = os.environ.get("JAVA_HOME")
    paths = [Path(env) / "bin" / "javaw.exe"] if env else []
    for root in roots:
        if root.exists():
            paths += list(root.rglob("javaw.exe")) + list(root.rglob("java.exe"))
    found = {}
    for path in paths:
        try:
            out = subprocess.check_output([str(path), "-version"], stderr=subprocess.STDOUT, text=True, timeout=5)
            match = re.search(r'"(\d+)', out.splitlines()[0])
            major = int(match.group(1)) if match else None
            major = 8 if major == 1 else major
            if major in (17, 21):
                found.setdefault(major, path.resolve())
        except Exception:
            continue
    return sorted(found.items())


def post_json(url, payload, bearer=None):
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    if bearer:
        headers["Authorization"] = f"Bearer {bearer}"
    request = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        detail = error.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {error.code}: {detail}") from error


def get_json(url, bearer):
    request = urllib.request.Request(url, headers={"Authorization": f"Bearer {bearer}", "Accept": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        detail = error.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"HTTP {error.code}: {detail}") from error


def fetch_json_url(url):
    request = urllib.request.Request(url, headers={"User-Agent": "UKL-Launcher/0.1"})
    with urllib.request.urlopen(request, timeout=30) as response:
        return json.loads(response.read().decode("utf-8"))


def download_file(url, destination, progress=None):
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(destination.suffix + ".part")
    request = urllib.request.Request(url, headers={"User-Agent": "UKL-Launcher/0.1"})
    with urllib.request.urlopen(request, timeout=60) as response, temporary.open("wb") as output:
        total = int(response.headers.get("Content-Length", "0"))
        received = 0
        while True:
            chunk = response.read(1024 * 256)
            if not chunk:
                break
            output.write(chunk)
            received += len(chunk)
            if progress and total:
                progress(received, total)
    temporary.replace(destination)


def safe_extract_zip(archive_path, target_dir):
    import zipfile
    target_dir = Path(target_dir).resolve()
    with zipfile.ZipFile(archive_path) as archive:
        for member in archive.infolist():
            target = (target_dir / member.filename).resolve()
            if target != target_dir and target_dir not in target.parents:
                raise RuntimeError(f"안전하지 않은 ZIP 경로가 있어 중단했습니다: {member.filename}")
        archive.extractall(target_dir)


def update_from_manifest(manifest_url, game_dir, progress=None):
    manifest = fetch_json_url(manifest_url)
    version = str(manifest.get("version", "unknown"))
    files = manifest.get("files", [])
    if files:
        for item in files:
            relative = Path(item["path"])
            if relative.is_absolute() or ".." in relative.parts:
                raise RuntimeError(f"허용되지 않은 업데이트 경로: {relative}")
            destination = Path(game_dir) / relative
            if item.get("sha256") and destination.exists():
                import hashlib as _hashlib
                digest = _hashlib.sha256(destination.read_bytes()).hexdigest()
                if digest.lower() == item["sha256"].lower():
                    continue
            download_file(item["url"], destination, progress)
    elif manifest.get("download"):
        archive = Path(game_dir) / ".ukl_update.zip"
        download_file(manifest["download"], archive, progress)
        safe_extract_zip(archive, game_dir)
        archive.unlink(missing_ok=True)
    else:
        raise RuntimeError("manifest에 files 또는 download 항목이 없습니다.")
    return version


def prepare_vanilla_client(version, game_dir, progress=None):
    catalog = fetch_json_url("https://launchermeta.mojang.com/mc/game/version_manifest_v2.json")
    entry = next((item for item in catalog.get("versions", []) if item.get("id") == version), None)
    if not entry:
        raise RuntimeError(f"Minecraft 버전 {version}을 공식 목록에서 찾지 못했습니다.")
    metadata_path = Path(game_dir) / "versions" / version / f"{version}.json"
    metadata_path.parent.mkdir(parents=True, exist_ok=True)
    if not metadata_path.exists():
        download_file(entry["url"], metadata_path, progress)
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    client_url = metadata.get("downloads", {}).get("client", {}).get("url")
    if not client_url:
        raise RuntimeError("이 Minecraft 버전의 client.jar 다운로드 주소가 없습니다.")
    client_path = metadata_path.parent / f"{version}.jar"
    if not client_path.exists():
        download_file(client_url, client_path, progress)
    return metadata


def install_forge_client(minecraft_version, forge_version, game_dir, java_path, progress=None):
    if not forge_version:
        raise RuntimeError("설정에서 로더 버전을 먼저 입력하세요. 예: 47.3.0")
    if not java_path or not Path(java_path).exists():
        raise RuntimeError("사용할 Java 실행 파일을 찾지 못했습니다. 설정 마법사에서 Java를 다시 검색하세요.")
    game_dir = Path(game_dir)
    game_dir.mkdir(parents=True, exist_ok=True)
    profile_path = game_dir / "launcher_profiles.json"
    if not profile_path.exists():
        profile_path.write_text(json.dumps({
            "profiles": {},
            "selectedProfile": "",
            "clientToken": str(uuid.uuid4()),
            "authenticationDatabase": {},
            "launcherVersion": {"name": "UKL", "format": 21, "profilesFormat": 1}
        }, ensure_ascii=False, indent=2), encoding="utf-8")
    installer_name = f"forge-{minecraft_version}-{forge_version}-installer.jar"
    installer_path = game_dir / ".ukl" / installer_name
    installer_url = f"https://maven.minecraftforge.net/net/minecraftforge/forge/{minecraft_version}-{forge_version}/{installer_name}"
    if not installer_path.exists():
        download_file(installer_url, installer_path, progress)
    java = Path(java_path)
    if java.name.lower() == "javaw.exe":
        java = java.with_name("java.exe")
    if not java.exists():
        java = Path(java_path)
    # Forge SimpleInstaller는 --target 옵션을 지원하지 않습니다.
    # --installClient 다음에 게임 폴더를 직접 인자로 전달해야 합니다.
    command = [str(java), "-jar", str(installer_path), "--installClient", str(game_dir)]
    result = subprocess.run(command, cwd=str(game_dir), capture_output=True, text=True, timeout=600)
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "Forge 설치기가 오류를 반환했습니다.").strip()
        raise RuntimeError(f"Forge 클라이언트 설치 실패\n{detail[-3000:]}")
    version_id = f"{minecraft_version}-forge-{forge_version}"
    version_json = game_dir / "versions" / version_id / f"{version_id}.json"
    if not version_json.exists():
        candidates = list((game_dir / "versions").glob("*/*.json")) if (game_dir / "versions").exists() else []
        if not candidates:
            raise RuntimeError("Forge 설치는 종료됐지만 설치된 version JSON을 찾지 못했습니다.")
    return version_id


def _merge_version_json(game_dir, version_id):
    """Forge JSON의 inheritsFrom을 따라가며 실행에 필요한 값을 합칩니다."""
    versions_dir = Path(game_dir) / "versions"
    current = json.loads((versions_dir / version_id / f"{version_id}.json").read_text(encoding="utf-8"))
    parent_id = current.get("inheritsFrom")
    if parent_id:
        parent = _merge_version_json(game_dir, parent_id)
        merged = dict(parent)
        merged["libraries"] = parent.get("libraries", []) + current.get("libraries", [])
        merged["arguments"] = {
            "jvm": parent.get("arguments", {}).get("jvm", []) + current.get("arguments", {}).get("jvm", []),
            "game": parent.get("arguments", {}).get("game", []) + current.get("arguments", {}).get("game", [])
        }
        merged.update({k: v for k, v in current.items() if k not in ("libraries", "arguments")})
        return merged
    return current


def _library_path(library):
    name = library.get("name", "")
    parts = name.split(":")
    if len(parts) < 3:
        return None
    group, artifact, version = parts[:3]
    classifier = parts[3] if len(parts) > 3 else ""
    filename = f"{artifact}-{version}{('-' + classifier) if classifier else ''}.jar"
    return Path(*group.split(".")) / artifact / version / filename


def _library_allowed(library):
    for rule in library.get("rules", []):
        if rule.get("os", {}).get("name") not in (None, "windows"):
            continue
        if rule.get("action") == "disallow":
            return False
    return True


def prepare_runtime_files(game_dir, version_id, progress=None):
    """Forge/vanilla JSON에 선언된 libraries와 assets를 내려받습니다."""
    game_dir = Path(game_dir)
    metadata = _merge_version_json(game_dir, version_id)
    libraries_dir = game_dir / "libraries"
    base_url = "https://libraries.minecraft.net/"
    native_archives = []
    for library in metadata.get("libraries", []):
        if not _library_allowed(library):
            continue
        downloads = library.get("downloads", {})
        artifact = downloads.get("artifact")
        relative = Path(artifact["path"]) if artifact and artifact.get("path") else _library_path(library)
        if not relative:
            continue
        destination = libraries_dir / relative
        if not destination.exists():
            url = artifact.get("url") if artifact else base_url + str(relative).replace(os.sep, "/")
            download_file(url, destination, progress)
        natives = library.get("natives", {}).get("windows")
        classifiers = downloads.get("classifiers", {})
        if natives and natives in classifiers:
            native = classifiers[natives]
            native_path = libraries_dir / native["path"]
            if not native_path.exists():
                download_file(native["url"], native_path, progress)
            native_archives.append(native_path)
    natives_dir = game_dir / "natives" / version_id
    natives_dir.mkdir(parents=True, exist_ok=True)
    import zipfile
    for archive_path in native_archives:
        with zipfile.ZipFile(archive_path) as archive:
            for member in archive.infolist():
                if member.is_dir() or member.filename.startswith("META-INF/"):
                    continue
                target = (natives_dir / member.filename).resolve()
                if natives_dir.resolve() not in target.parents:
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(member) as source, target.open("wb") as output:
                    output.write(source.read())
    asset_index = metadata.get("assetIndex")
    if asset_index and asset_index.get("id") and asset_index.get("url"):
        index_path = game_dir / "assets" / "indexes" / f"{asset_index['id']}.json"
        if not index_path.exists():
            download_file(asset_index["url"], index_path, progress)
        objects = json.loads(index_path.read_text(encoding="utf-8")).get("objects", {})
        for obj in objects.values():
            digest = obj.get("hash")
            if not digest:
                continue
            object_path = game_dir / "assets" / "objects" / digest[:2] / digest
            if not object_path.exists():
                download_file(f"https://resources.download.minecraft.net/{digest[:2]}/{digest}", object_path, progress)
    return metadata


def _argument_values(value, substitutions):
    """version JSON의 문자열/배열 인수를 Java 인수 목록으로 평탄화합니다."""
    if isinstance(value, dict):
        rules = value.get("rules", [])
        for rule in rules:
            features = rule.get("features", {})
            if features and any(bool(expected) for expected in features.values()):
                # UKL은 일반 정품 계정·일반 실행이므로 demo/quick-play 조건은 비활성입니다.
                if rule.get("action") == "allow":
                    return []
            if rule.get("os", {}).get("name") not in (None, "windows"):
                if rule.get("action") == "allow":
                    return []
            elif rule.get("action") == "disallow":
                return []
        return _argument_values(value.get("value", ""), substitutions)
    if isinstance(value, (list, tuple)):
        result = []
        for item in value:
            result.extend(_argument_values(item, substitutions))
        return result
    text = str(value)
    for key, replacement in substitutions.items():
        text = text.replace("${" + key + "}", str(replacement))
    if "${" in text:
        return []
    return [text]


def launch_minecraft(game_dir, version_id, java_path, ram_gb, width, height, tokens, server_address=""):
    game_dir = Path(game_dir)
    metadata = prepare_runtime_files(game_dir, version_id)
    profile = tokens.get("profile", {})
    access_token = tokens.get("minecraft_access_token") or tokens.get("access_token")
    if not profile.get("id") or not profile.get("name") or not access_token:
        raise RuntimeError("Minecraft 인증 정보가 없습니다. 먼저 Microsoft 로그인을 완료하세요.")
    assets = metadata.get("assetIndex", {})
    natives_dir = game_dir / "natives" / version_id
    natives_dir.mkdir(parents=True, exist_ok=True)
    libraries = []
    for library in metadata.get("libraries", []):
        if _library_allowed(library):
            # Forge 1.20.x의 client/srg JAR는 Forge MinecraftLocator가
            # libraryDirectory에서 모듈로 직접 로드합니다. 일반 classpath에
            # 함께 넣으면 minecraft/client 모듈이 중복되어 ResolutionException이 납니다.
            if library.get("name", "").startswith("net.minecraft:client:"):
                continue
            relative = _library_path(library)
            artifact = library.get("downloads", {}).get("artifact")
            if artifact and artifact.get("path"):
                relative = Path(artifact["path"])
            if relative:
                libraries.append(str(game_dir / "libraries" / relative))
    substitutions = {
        "auth_player_name": profile["name"], "auth_uuid": profile["id"],
        "auth_access_token": access_token, "auth_session": access_token,
        "clientid": tokens.get("client_id", ""), "user_type": "msa",
        "version_name": version_id, "game_directory": game_dir,
        "assets_root": game_dir / "assets", "assets_index_name": assets.get("id", ""),
        "natives_directory": natives_dir, "launcher_name": "UKL", "launcher_version": "1.0",
        "classpath": os.pathsep.join(libraries), "version_type": "release",
        "resolution_width": width, "resolution_height": height,
        "library_directory": game_dir / "libraries", "classpath_separator": os.pathsep
    }
    jvm_args, game_args = [], []
    argument_block = metadata.get("arguments", {})
    for item in argument_block.get("jvm", []):
        jvm_args.extend(_argument_values(item, substitutions))
    for item in argument_block.get("game", []):
        game_args.extend(_argument_values(item, substitutions))
    if "--xuid" in game_args:
        index = game_args.index("--xuid")
        if index + 1 >= len(game_args) or game_args[index + 1].startswith("--"):
            game_args.pop(index)
    if "-cp" not in jvm_args and "-classpath" not in jvm_args:
        jvm_args += ["-cp", substitutions["classpath"]]
    command = [str(java_path), f"-Xms{max(1, int(ram_gb) // 2)}G", f"-Xmx{int(ram_gb)}G"]
    command += jvm_args + [metadata.get("mainClass", "net.minecraft.client.main.Main")] + game_args
    if server_address:
        host, sep, port = server_address.strip().partition(":")
        if host:
            # 1.20.x의 quick-play 인수는 Forge 초기화가 끝난 뒤
            # 메인 화면을 거치지 않고 멀티플레이 서버로 연결합니다.
            destination = f"{host}:{port}" if sep and port.isdigit() else host
            command += ["--quickPlayMultiplayer", destination]
    log_path = game_dir / "logs" / "ukl-launch.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_file = log_path.open("w", encoding="utf-8", errors="replace")
    safe_command = ["<minecraft-token>" if item == access_token else item for item in command]
    log_file.write("UKL command:\n" + subprocess.list2cmdline(safe_command) + "\n\n")
    log_file.flush()
    process = subprocess.Popen(command, cwd=str(game_dir), stdout=log_file, stderr=subprocess.STDOUT,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return process, command, log_file, log_path


def authenticate_minecraft(microsoft_tokens):
    access_token = microsoft_tokens.get("access_token")
    if not access_token:
        raise RuntimeError("Microsoft access token이 없습니다.")
    try:
        xbl = post_json("https://user.auth.xboxlive.com/user/authenticate", {
            "Properties": {"AuthMethod": "RPS", "SiteName": "user.auth.xboxlive.com", "RpsTicket": f"d={access_token}"},
            "RelyingParty": "http://auth.xboxlive.com", "TokenType": "JWT"
        })
    except Exception as error:
        raise RuntimeError(f"[1/5 Xbox Live 인증] {error}") from error
    xbl_token = xbl["Token"]
    user_hash = xbl["DisplayClaims"]["xui"][0]["uhs"]
    try:
        xsts = post_json("https://xsts.auth.xboxlive.com/xsts/authorize", {
            "Properties": {"SandboxId": "RETAIL", "UserTokens": [xbl_token]},
            "RelyingParty": "rp://api.minecraftservices.com/", "TokenType": "JWT"
        })
    except Exception as error:
        raise RuntimeError(f"[2/5 XSTS 인증] {error}") from error
    xsts_token = xsts["Token"]
    try:
        minecraft = post_json("https://api.minecraftservices.com/authentication/login_with_xbox", {
            "identityToken": f"XBL3.0 x={user_hash};{xsts_token}"
        })
    except Exception as error:
        raise RuntimeError(f"[3/5 Minecraft Services 인증] {error}") from error
    minecraft_token = minecraft.get("access_token")
    if not minecraft_token:
        raise RuntimeError("[3/5 Minecraft Services 인증] Minecraft access token을 받지 못했습니다.")
    try:
        entitlements = get_json("https://api.minecraftservices.com/entitlements/mcstore", minecraft_token)
    except Exception as error:
        raise RuntimeError(f"[4/5 Minecraft 보유 권한 확인] {error}") from error
    try:
        profile = get_json("https://api.minecraftservices.com/minecraft/profile", minecraft_token)
    except Exception as error:
        raise RuntimeError(f"[5/5 Minecraft 프로필 확인] {error}") from error
    items = {item.get("name") for item in entitlements.get("items", [])}
    if not ({"product_minecraft", "game_minecraft"} & items):
        raise RuntimeError("[4/5 Minecraft 보유 권한 확인] 이 Microsoft 계정에서 Minecraft Java Edition 보유 권한을 확인하지 못했습니다.")
    return {"minecraft_access_token": minecraft_token, "minecraft_expires_in": minecraft.get("expires_in"), "profile": profile, "entitlements": entitlements}


def create_pkce_pair():
    verifier = secrets.token_urlsafe(64)
    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
    return verifier, challenge


def run_microsoft_login(client_id, on_result):
    redirect_uri = "http://localhost:8765"
    state = secrets.token_urlsafe(24)
    verifier, challenge = create_pkce_pair()
    result = {}
    finished = threading.Event()

    class CallbackHandler(BaseHTTPRequestHandler):
        def do_GET(self):
            query = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            result.update({key: values[0] for key, values in query.items() if values})
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            self.wfile.write("<h2>UKL 로그인 결과를 받았습니다.</h2><p>이 창을 닫고 UKL로 돌아가세요.</p>".encode("utf-8"))
            finished.set()

        def log_message(self, *_):
            pass

    server = HTTPServer(("127.0.0.1", 8765), CallbackHandler)
    params = {
        "client_id": client_id,
        "response_type": "code",
        "redirect_uri": redirect_uri,
        "response_mode": "query",
        "scope": "openid profile XboxLive.signin offline_access",
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "prompt": "select_account"
    }
    url = "https://login.microsoftonline.com/consumers/oauth2/v2.0/authorize?" + urllib.parse.urlencode(params)
    webbrowser.open(url)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    finished.wait(timeout=300)
    server.shutdown()
    server.server_close()
    if result.get("state") != state:
        on_result(False, "로그인 상태 검증에 실패했습니다.")
        return
    if "error" in result:
        on_result(False, result.get("error_description", result["error"]))
        return
    code = result.get("code")
    if not code:
        on_result(False, "인증 코드를 받지 못했습니다.")
        return
    token_data = urllib.parse.urlencode({"client_id": client_id, "grant_type": "authorization_code", "code": code, "redirect_uri": redirect_uri, "code_verifier": verifier}).encode()
    request = urllib.request.Request("https://login.microsoftonline.com/consumers/oauth2/v2.0/token", data=token_data, method="POST")
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            tokens = json.loads(response.read().decode("utf-8"))
        minecraft_data = authenticate_minecraft(tokens)
        tokens.update(minecraft_data)
        TOKEN_PATH.write_text(json.dumps(tokens, ensure_ascii=False, indent=2), encoding="utf-8")
        profile = minecraft_data["profile"]
        on_result(True, f"Minecraft 인증 완료: {profile.get('name', '알 수 없음')}\nUUID: {profile.get('id', '')}")
    except Exception as error:
        on_result(False, f"토큰 교환에 실패했습니다: {error}")


class Wizard(tk.Toplevel):
    def __init__(self, parent, config, done):
        super().__init__(parent)
        self.parent, self.config, self.done, self.page = parent, config, done, 0
        self.title("UKL 처음 설정")
        self.geometry("620x430")
        self.resizable(False, False)
        self.configure(bg="#182630")
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.grab_set()
        self.render()

    def render(self):
        for child in self.winfo_children(): child.destroy()
        if self.page == 0:
            self.heading("UKL에 오신 것을 환영합니다", "처음 한 번만 기본 설정을 진행합니다. 이후에는 UKL에서 게임 준비와 실행을 관리합니다.")
            self.text("현재 단계에서는 독립형 화면, 설정 저장, Java 확인까지 구현되어 있습니다. Microsoft 로그인과 Minecraft 직접 실행은 다음 단계에서 연결합니다.")
            self.nav(False, "시작하기")
        elif self.page == 1:
            self.heading("Java 환경 확인", "Java 17과 21을 자동으로 검색합니다. Minecraft 1.20.1은 Java 17을 우선 사용합니다.")
            found = find_java()
            self.config["selected_java"] = str(next((p for v, p in found if v == 17), found[0][1] if found else ""))
            if found:
                for version, path in found: self.text(f"✓ Java {version}: {path}", "#bde8c6")
            else: self.text("Java 17 또는 Java 21을 찾지 못했습니다. 나중에 설정에서 다시 검색할 수 있습니다.", "#ffd0a8")
            self.nav(True)
        elif self.page == 2:
            self.heading("게임 기본 설정", "친구의 컴퓨터 사양에 맞춰 기본 RAM과 화면 크기를 설정합니다.")
            box = tk.Frame(self, bg="#182630"); box.pack(anchor="w", padx=42, pady=28)
            tk.Label(box, text="RAM 할당량 (GB)", fg="white", bg="#182630").grid(row=0, column=0, sticky="w", pady=10)
            self.ram = tk.IntVar(value=int(self.config.get("ram_gb", 6))); ttk.Spinbox(box, from_=2, to=32, textvariable=self.ram, width=8).grid(row=0, column=1, padx=28)
            tk.Label(box, text="화면 크기", fg="white", bg="#182630").grid(row=1, column=0, sticky="w", pady=10)
            self.width = tk.IntVar(value=int(self.config.get("width", 1280))); self.height = tk.IntVar(value=int(self.config.get("height", 720)))
            tk.Entry(box, textvariable=self.width, width=8).grid(row=1, column=1, sticky="w", padx=28); tk.Entry(box, textvariable=self.height, width=8).grid(row=1, column=1, sticky="e")
            self.nav(True)
        else:
            self.heading("설정 완료", "기본 설정이 저장되었습니다. 다음 단계에서 Microsoft 로그인, 모드팩 업데이트, Minecraft 직접 실행을 연결합니다.")
            self.text("다음부터는 UKL을 실행하면 이 화면 대신 메인 런처가 표시됩니다.", "#bde8c6")
            self.nav(False, "완료")

    def heading(self, title, desc):
        tk.Label(self, text=title, font=("Segoe UI", 22, "bold"), fg="white", bg="#182630").pack(anchor="w", padx=32, pady=(28, 6))
        tk.Label(self, text=desc, fg="#b8cad6", bg="#182630", wraplength=540, justify="left").pack(anchor="w", padx=32)

    def text(self, value, color="#d7e8f5"):
        tk.Label(self, text=value, fg=color, bg="#182630", wraplength=540, justify="left").pack(anchor="w", padx=42, pady=12)

    def nav(self, back, next_text="다음"):
        bar = tk.Frame(self, bg="#182630"); bar.pack(side="bottom", fill="x", padx=32, pady=24)
        if back: tk.Button(bar, text="이전", command=self.back, width=12, bg="#344c5d", fg="white", relief="flat").pack(side="left")
        tk.Button(bar, text=next_text, command=self.next, width=12, bg="#3c91d8", fg="white", relief="flat").pack(side="right")

    def next(self):
        if self.page == 2:
            self.config.update(ram_gb=int(self.ram.get()), width=int(self.width.get()), height=int(self.height.get()))
        if self.page < 3: self.page += 1; self.render()
        else:
            self.config["setup_complete"] = True; save_config(self.config); self.destroy(); self.done()

    def back(self):
        if self.page > 0: self.page -= 1; self.render()


class Launcher(tk.Tk):
    def __init__(self):
        super().__init__(); self.config_data = load_config(); self.title("UKL"); self.geometry("960x560"); self.minsize(800, 480); self.configure(bg="#15202b")
        self.status = tk.StringVar(value="준비되었습니다."); self.version = tk.StringVar(value=f"클라이언트 {self.config_data.get('version', '0.0.0')}"); self.build_ui(); self.after(250, self.detect_java)
        if not self.config_data.get("setup_complete"): self.after(350, self.open_wizard)

    def build_ui(self):
        top = tk.Frame(self, bg="#0d141b"); top.pack(fill="x")
        tk.Label(top, text="UKL", font=("Segoe UI", 22, "bold"), fg="white", bg="#0d141b").pack(side="left", padx=22, pady=14); tk.Label(top, text="UKL Launcher", fg="#a9c7dc", bg="#0d141b").pack(side="left"); tk.Label(top, textvariable=self.version, fg="#9bb2c3", bg="#0d141b").pack(side="right", padx=22)
        body = tk.Frame(self, bg="#15202b"); body.pack(fill="both", expand=True, padx=28, pady=24)
        tk.Label(body, text="UKL Minecraft", font=("Segoe UI", 28, "bold"), fg="white", bg="#15202b").pack(anchor="w"); tk.Label(body, text="독립형 런처를 단계별로 준비하고 있습니다.", fg="#b7c6d1", bg="#15202b").pack(anchor="w", pady=(4, 22))
        card = tk.Frame(body, bg="#213442", padx=20, pady=18); card.pack(fill="x")
        self.java_label = tk.Label(card, text="Java 검색 중...", fg="#d7e8f5", bg="#213442"); self.java_label.pack(anchor="w"); self.ram_label = tk.Label(card, text=f"RAM: {self.config_data.get('ram_gb', 6)}GB", fg="#b7c6d1", bg="#213442"); self.ram_label.pack(anchor="w", pady=(8, 0)); self.account_label = tk.Label(card, text=self.account_status(), fg="#b7c6d1", bg="#213442"); self.account_label.pack(anchor="w", pady=(4, 0)); tk.Label(card, text=f"Minecraft {self.config_data.get('minecraft_version')} / {self.config_data.get('loader')}", fg="#b7c6d1", bg="#213442").pack(anchor="w", pady=(4, 0))
        buttons = tk.Frame(body, bg="#15202b"); buttons.pack(anchor="w", pady=20); tk.Button(buttons, text="게임 시작", command=self.start_game, width=14, height=2, bg="#3c91d8", fg="white", relief="flat", font=("Segoe UI", 11, "bold")).pack(side="left"); tk.Button(buttons, text="Microsoft 로그인", command=self.microsoft_login, width=16, height=2, bg="#344c5d", fg="white", relief="flat").pack(side="left", padx=8); tk.Button(buttons, text="모드팩 업데이트", command=self.update_modpack, width=16, height=2, bg="#344c5d", fg="white", relief="flat").pack(side="left", padx=8); tk.Button(buttons, text="게임 파일 준비", command=self.prepare_client, width=14, height=2, bg="#344c5d", fg="white", relief="flat").pack(side="left", padx=8); tk.Button(buttons, text="Forge 설치", command=self.install_forge, width=12, height=2, bg="#344c5d", fg="white", relief="flat").pack(side="left", padx=8); tk.Button(buttons, text="설정", command=self.open_settings, width=10, height=2, bg="#344c5d", fg="white", relief="flat").pack(side="left")
        tk.Label(body, textvariable=self.status, fg="#9fc5dc", bg="#15202b", anchor="w").pack(fill="x", side="bottom")

    def detect_java(self):
        found = find_java()
        if found:
            version, path = next(((v, p) for v, p in found if v == 17), found[0]); self.config_data["selected_java"] = str(path); self.java_label.config(text=f"Java {version} 자동 선택: {path}"); save_config(self.config_data)
        else: self.java_label.config(text="Java 17 또는 Java 21을 찾지 못했습니다.")

    def account_status(self):
        if TOKEN_PATH.exists():
            try:
                profile = json.loads(TOKEN_PATH.read_text(encoding="utf-8")).get("profile", {})
                if profile.get("name"): return f"Minecraft 계정: {profile['name']} (인증 저장됨)"
            except Exception:
                pass
        return "Minecraft 계정: 로그인 필요 또는 인증 승인 대기"

    def run_background(self, work, success_message):
        self.status.set("작업을 진행 중입니다...")
        def worker():
            try:
                result = work()
                message = success_message(result)
                self.after(0, lambda message=message: (self.status.set(message), messagebox.showinfo("UKL", message)))
            except Exception as error:
                detail = str(error)
                self.after(0, lambda detail=detail: (self.status.set("작업 실패: " + detail[:120]), messagebox.showerror("UKL 작업 실패", detail)))
        threading.Thread(target=worker, daemon=True).start()

    def update_modpack(self):
        url = self.config_data.get("manifest_url", "").strip()
        if not url:
            messagebox.showinfo("모드팩 업데이트", "설정에서 manifest URL을 먼저 입력하세요.")
            self.open_settings(); return
        Path(self.config_data["game_dir"]).mkdir(parents=True, exist_ok=True)
        self.run_background(lambda: update_from_manifest(url, self.config_data["game_dir"]), lambda v: f"모드팩 업데이트 완료: {v}")

    def prepare_client(self):
        version = self.config_data.get("minecraft_version", "1.20.1")
        game_dir = self.config_data.get("game_dir") or str(CONFIG_DIR / "MinecraftClient")
        self.run_background(lambda: prepare_vanilla_client(version, game_dir), lambda _: f"Minecraft {version} 기본 파일 준비 완료")

    def install_forge(self):
        minecraft_version = self.config_data.get("minecraft_version", "1.20.1")
        forge_version = self.config_data.get("loader_version", "").strip()
        game_dir = self.config_data.get("game_dir") or str(CONFIG_DIR / "MinecraftClient")
        java_path = self.config_data.get("selected_java", "")
        if str(self.config_data.get("loader", "")).lower() != "forge":
            messagebox.showinfo("Forge 설치", "설정의 로더를 forge로 선택한 뒤 다시 시도하세요.")
            return
        self.run_background(lambda: install_forge_client(minecraft_version, forge_version, game_dir, java_path), lambda v: f"Forge 설치 완료: {v}")

    def open_wizard(self): Wizard(self, self.config_data, self.wizard_done)
    def wizard_done(self): self.ram_label.config(text=f"RAM: {self.config_data.get('ram_gb', 6)}GB"); self.detect_java(); self.status.set("초기 설정이 저장되었습니다.")
    def start_game(self):
        tokens = {}
        if TOKEN_PATH.exists():
            try:
                tokens = json.loads(TOKEN_PATH.read_text(encoding="utf-8"))
            except Exception:
                tokens = {}
        if not tokens.get("minecraft_access_token"):
            messagebox.showinfo("UKL 게임 시작", "먼저 Microsoft 로그인을 완료하세요.")
            return
        game_dir = self.config_data.get("game_dir") or str(CONFIG_DIR / "MinecraftClient")
        loader = str(self.config_data.get("loader", "")).lower()
        forge_version = str(self.config_data.get("loader_version", "")).strip()
        minecraft_version = self.config_data.get("minecraft_version", "1.20.1")
        if loader != "forge" or not forge_version:
            messagebox.showinfo("UKL 게임 시작", "설정에서 forge와 Forge 버전을 지정한 뒤 Forge 설치를 먼저 완료하세요.")
            return
        version_id = f"{minecraft_version}-forge-{forge_version}"
        version_json = Path(game_dir) / "versions" / version_id / f"{version_id}.json"
        if not version_json.exists():
            messagebox.showinfo("UKL 게임 시작", "Forge 설치 결과를 찾지 못했습니다. 먼저 게임 파일 준비와 Forge 설치를 실행하세요.")
            return
        java_path = self.config_data.get("selected_java", "")
        if java_path.lower().endswith("javaw.exe"):
            java_path = java_path[:-9] + "java.exe"
        self.status.set("Minecraft 실행 파일과 라이브러리를 준비하는 중입니다...")
        def worker():
            try:
                process, command, log_file, log_path = launch_minecraft(game_dir, version_id, java_path,
                    self.config_data.get("ram_gb", 6), self.config_data.get("width", 1280),
                    self.config_data.get("height", 720), tokens, self.config_data.get("server_address", ""))
                self.after(0, lambda: self.status.set(f"Minecraft 실행 중입니다. (PID {process.pid})"))
                return_code = process.wait()
                log_file.write(f"\n\nMinecraft 종료 코드: {return_code}\n")
                log_file.close()
                if return_code == 0:
                    message = "Minecraft가 정상적으로 종료되었습니다."
                else:
                    message = f"Minecraft가 실행 직후 종료되었습니다. 종료 코드: {return_code}\n로그: {log_path}"
                self.after(0, lambda message=message, code=return_code: (self.status.set(message.split("\n")[0]), messagebox.showinfo("UKL Minecraft", message) if code == 0 else messagebox.showerror("UKL Minecraft 실행 실패", message)))
            except Exception as error:
                detail = str(error)
                self.after(0, lambda detail=detail: (self.status.set("Minecraft 실행 실패"), messagebox.showerror("UKL 게임 시작 실패", detail)))
        threading.Thread(target=worker, daemon=True).start()

    def microsoft_login(self):
        if not self.config_data.get("microsoft_client_id"):
            messagebox.showinfo("Microsoft 로그인 준비", "먼저 설정에서 Microsoft Client ID를 입력하세요. Client Secret이나 비밀번호는 입력하지 않습니다.")
            self.open_settings()
            return
        client_id = self.config_data["microsoft_client_id"].strip()
        self.status.set("Microsoft 로그인 창을 여는 중입니다...")
        threading.Thread(target=run_microsoft_login, args=(client_id, self.login_finished), daemon=True).start()

    def login_finished(self, success, message):
        def update():
            if success:
                self.config_data["microsoft_signed_in"] = True
                save_config(self.config_data)
                self.account_label.config(text=self.account_status())
                self.status.set("Minecraft 계정 인증 완료")
                messagebox.showinfo("UKL", message)
            else:
                self.status.set("Microsoft 로그인 실패")
                messagebox.showerror("Microsoft 로그인", message)
        self.after(0, update)

    def open_settings(self):
        win = tk.Toplevel(self); win.title("UKL 설정"); win.geometry("680x500"); win.configure(bg="#182630"); fields = {}
        for i, (label, key) in enumerate((("업데이트 manifest URL", "manifest_url"), ("게임 폴더", "game_dir"), ("Minecraft 버전", "minecraft_version"), ("로더", "loader"), ("로더 버전", "loader_version"), ("서버 주소", "server_address"), ("Microsoft Client ID", "microsoft_client_id"))):
            tk.Label(win, text=label, fg="white", bg="#182630").grid(row=i, column=0, sticky="w", padx=18, pady=10); var = tk.StringVar(value=str(self.config_data.get(key, ""))); fields[key] = var; tk.Entry(win, textvariable=var, width=42).grid(row=i, column=1, padx=8, pady=10)
            if key == "game_dir": tk.Button(win, text="찾기", command=lambda v=var: v.set(filedialog.askdirectory() or v.get())).grid(row=i, column=2)
        def save():
            for key, var in fields.items(): self.config_data[key] = var.get()
            save_config(self.config_data); win.destroy(); self.status.set("설정이 저장되었습니다.")
        tk.Button(win, text="Client ID 발급 안내", command=lambda: webbrowser.open("https://entra.microsoft.com/"), bg="#344c5d", fg="white", relief="flat").grid(row=7, column=0, pady=24)
        tk.Button(win, text="저장", command=save, bg="#3c91d8", fg="white", relief="flat", width=15).grid(row=7, column=1, pady=24)


if __name__ == "__main__": Launcher().mainloop()
