# UKL 런처

UKL은 친구들과 함께 사용하는 Minecraft Java Edition용 독립 런처 프로젝트입니다.

## 이번 버전에 포함된 기능

- Microsoft 로그인 및 단계별 오류 표시
- Xbox Live·XSTS·Minecraft Services 인증 연결
- Minecraft 계정 프로필 확인 구조
- Java 17·21 자동 탐색 및 Java 17 우선 선택
- RAM·화면 크기 저장
- Minecraft 버전·로더·로더 버전 설정
- 모드팩 manifest 기반 파일 업데이트
- ZIP 모드팩 업데이트 시 경로 탈출 방지
- 공식 Minecraft 버전 메타데이터와 client.jar 준비
- Forge 설치기 다운로드 및 지정 게임 폴더 설치
- Forge/vanilla version JSON 상속 처리, libraries·assets 자동 준비
- Microsoft 인증 토큰을 이용한 Forge Minecraft 직접 실행
- 실행 실패 시 종료 코드·전체 실행 명령·로그(`logs/ukl-launch.log`) 기록
- 현재 테스트 기본 서버 주소: `127.0.0.1:25565` (같은 컴퓨터에서 실행하는 서버)
- 게임 폴더 설정
- 서버 주소 설정
- Windows 단일 설치 프로그램

## 현재 제한

새 Azure 앱은 Minecraft Services API에서 `Invalid app registration`으로 거부될 수 있습니다. 이 경우 Microsoft/Xbox 인증 코드는 정상이어도 Minecraft API 검토 및 허용 목록 등록이 끝날 때까지 [공식 신청 페이지](https://aka.ms/Appreginfo)를 통해 승인을 받아야 합니다.

`게임 시작` 버튼은 Microsoft 인증, Forge 설치 결과, Java 경로를 확인한 뒤 Forge version JSON의 JVM/game arguments를 조립해 Minecraft를 직접 실행합니다. 처음 실행할 때 Forge와 vanilla JSON에 선언된 libraries 및 assets를 자동으로 준비하므로 다운로드 시간이 걸릴 수 있습니다.

## 빌드

Windows에서 Python 3.11 이상이 설치된 상태로 `build_windows.bat`를 실행합니다. 완료되면 다음 파일이 생성됩니다.

```text
dist\\UKL_Setup.exe
```

친구에게는 이 설치 파일 하나를 전달하면 됩니다.

## 설정

UKL 설정 파일:

```text
C:\\Users\\사용자이름\\AppData\\Roaming\\UKL\\launcher_config.json
```

설정 화면 항목:

- 업데이트 manifest URL
- 게임 폴더
- Minecraft 버전
- 로더 및 로더 버전
- 서버 주소
- Microsoft Client ID

현재 챕터에서는 같은 컴퓨터에서 실행하는 서버 테스트만 진행합니다. 공인 IP, 포트 포워딩, DDNS 및 친구의 외부 접속은 다음 챕터에서 별도로 구성합니다.

Client ID는 Azure 앱 등록의 `애플리케이션(클라이언트) ID`를 사용합니다. Client Secret이나 Microsoft 비밀번호는 입력하지 않습니다.

## manifest 형식

`manifest.example.json`을 참고하세요.

파일 목록 방식:

```json
{
  "version": "1.0.1",
  "minecraft": "1.20.1",
  "loader": "forge",
  "files": [
    {
      "path": "mods/example-mod.jar",
      "url": "https://example.com/files/example-mod.jar",
      "sha256": "파일의 SHA-256 해시"
    }
  ]
}
```

또는 `download`에 ZIP URL을 지정할 수 있습니다. ZIP에는 `mods`, `config`, `defaultconfigs`, `resourcepacks` 등을 넣고 `saves`, `screenshots`, `options.txt`, `servers.dat`는 넣지 않는 것을 권장합니다.

## 인증 테스트

Azure 앱 인증 설정:

```text
지원되는 계정 유형: 모든 Entra ID 테넌트 + 개인 Microsoft 계정
리디렉션 URI: http://localhost:8765
공용 클라이언트 흐름 허용: 예
```

인증 토큰은 현재 프로토타입에서 다음 위치에 저장됩니다.

```text
C:\\Users\\사용자이름\\AppData\\Roaming\\UKL\\auth_tokens.json
```

최종 배포 전에는 Windows DPAPI 또는 자격 증명 관리자로 교체해야 합니다.
