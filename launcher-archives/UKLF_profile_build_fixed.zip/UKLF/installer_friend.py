import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

APP_NAME = "UKLF"
INSTALL_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home())) / APP_NAME


def resource_root():
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS) / "payload"
    return Path(__file__).resolve().parent / "payload"


def create_shortcut(target):
    target = Path(target).resolve()
    desktop_expr = "[Environment]::GetFolderPath('Desktop')"
    script = (
        f"$desktop = {desktop_expr}; "
        f"New-Item -ItemType Directory -Force -Path $desktop | Out-Null; "
        f"$shortcut = Join-Path $desktop 'UKLF.lnk'; "
        "$ws = New-Object -ComObject WScript.Shell; "
        "$sc = $ws.CreateShortcut($shortcut); "
        f"$sc.TargetPath = '{target}'; "
        f"$sc.WorkingDirectory = '{target.parent}'; "
        f"$sc.IconLocation = '{target}'; "
        "$sc.Description = 'UKL 친구용 런처'; $sc.Save();"
    )
    result = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], check=False, capture_output=True, text=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if result.returncode != 0:
        raise RuntimeError(f"바탕화면 바로가기를 만들지 못했습니다: {result.stderr.strip() or 'PowerShell 오류'}")


def install():
    payload = resource_root()
    launcher = payload / "UKLF.exe"
    if not launcher.exists():
        raise RuntimeError("Friend launcher was not found inside the installer.")
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    subprocess.run(["taskkill", "/F", "/IM", "UKLF.exe"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    installed_launcher = INSTALL_DIR / "UKLF.exe"
    last_error = None
    for _ in range(10):
        try:
            shutil.copy2(launcher, installed_launcher)
            last_error = None
            break
        except PermissionError as error:
            last_error = error
            time.sleep(0.5)
    if last_error is not None:
        raise RuntimeError(f"Friend launcher is still running. Close it and try again.\n\nDetails: {last_error}")
    config = payload / "launcher_config.json"
    if config.exists() and not (INSTALL_DIR / "launcher_config.json").exists():
        shutil.copy2(config, INSTALL_DIR / "launcher_config.json")
    create_shortcut(INSTALL_DIR / "UKLF.exe")
    subprocess.Popen([str(INSTALL_DIR / "UKLF.exe")], cwd=str(INSTALL_DIR))


if __name__ == "__main__":
    try:
        install()
    except Exception as error:
        root = tk.Tk(); root.withdraw()
        messagebox.showerror("UKLF install failed", str(error))
        root.destroy()
        raise
