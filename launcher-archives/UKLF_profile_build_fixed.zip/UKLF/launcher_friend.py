import os

os.environ["UKL_FRIEND_BUILD"] = "1"
import launcher_v2

if __name__ == "__main__":
    launcher_v2.Launcher().mainloop()
