@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title UKLF Builder

echo ========================================
echo UKLF friend launcher build
echo ========================================
echo.
echo Enter your Microsoft Client ID below.
echo Do NOT enter a Client Secret or password.
echo.
where python >nul 2>&1
if errorlevel 1 goto NO_PYTHON
python --version
if errorlevel 1 goto NO_PYTHON

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist payload rmdir /s /q payload
mkdir payload

set "FRIEND_CLIENT_ID="
set /p "FRIEND_CLIENT_ID=> Client ID: "
if "%FRIEND_CLIENT_ID%"=="" goto NO_CLIENT_ID
>friend_build_settings.py echo MICROSOFT_CLIENT_ID = "%FRIEND_CLIENT_ID%"

echo [1/3] Building UKLF.exe...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name UKLF launcher_friend.py
if errorlevel 1 goto FAIL
if not exist dist\UKLF.exe goto FAIL
copy /y dist\UKLF.exe payload\UKLF.exe >nul
copy /y launcher_config.json payload\launcher_config.json >nul

echo [2/3] Building UKLF_Setup.exe...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name UKLF_Setup --add-binary "payload\UKLF.exe;payload" --add-data "payload\launcher_config.json;payload" installer_friend.py
if errorlevel 1 goto FAIL
if not exist dist\UKLF_Setup.exe goto FAIL

echo [3/3] BUILD COMPLETE
echo Installer: %CD%\dist\UKLF_Setup.exe
goto DONE

:NO_PYTHON
echo Python was not found.
goto FAIL

:NO_CLIENT_ID
echo Client ID was empty. Build cancelled.
goto FAIL

:FAIL
echo BUILD FAILED.
pause
endlocal
exit /b 1

:DONE
pause
endlocal
exit /b 0
