@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title UKL Builder

echo ========================================
echo UKL 설치 프로그램 빌드
 echo 현재 폴더: %CD%
echo ========================================
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo [오류] Python을 찾지 못했습니다.
  echo Python 3.11 이상을 설치하고 설치 중 Add Python to PATH를 체크하세요.
  goto FAIL
)

python --version
if errorlevel 1 goto FAIL

echo.
echo [1/4] PyInstaller 설치 또는 업데이트 중...
python -m pip install --upgrade pyinstaller
if errorlevel 1 goto FAIL

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist payload rmdir /s /q payload
mkdir payload

echo.
echo [2/4] UKL 런처 빌드 중...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name UKL launcher_v2.py
if errorlevel 1 goto FAIL
if not exist dist\UKL.exe (
  echo [오류] dist\UKL.exe가 생성되지 않았습니다.
  goto FAIL
)

copy /y dist\UKL.exe payload\UKL.exe >nul
copy /y launcher_config.json payload\launcher_config.json >nul

echo.
echo [3/4] UKL_Setup.exe 빌드 중...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name UKL_Setup --add-binary "payload\UKL.exe;payload" --add-data "payload\launcher_config.json;payload" installer.py
if errorlevel 1 goto FAIL
if not exist dist\UKL_Setup.exe (
  echo [오류] dist\UKL_Setup.exe가 생성되지 않았습니다.
  goto FAIL
)

echo.
echo [4/4] 완료
echo ----------------------------------------
echo 친구들에게 보낼 파일:
echo %CD%\dist\UKL_Setup.exe
echo ----------------------------------------
echo 빌드가 성공했습니다.
goto DONE

:FAIL
echo.
echo ========================================
echo 빌드에 실패했습니다.
echo 위에 표시된 오류 내용을 보내주세요.
echo ========================================

:DONE
echo.
pause
endlocal
