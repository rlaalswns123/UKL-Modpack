import os
import shutil
import subprocess
import sys
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

APP_NAME = "UKL"
INSTALL_DIR = Path(os.environ.get("LOCALAPPDATA", Path.home())) / APP_NAME


def resource_root():
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS) / "payload"
    return Path(__file__).resolve().parent / "payload"


def create_shortcut(target):
    desktop = Path(os.environ.get("USERPROFILE", str(Path.home()))) / "Desktop"
    desktop.mkdir(parents=True, exist_ok=True)
    shortcut = desktop / "UKL.lnk"
    script = (
        "$ws = New-Object -ComObject WScript.Shell; "
        f"$sc = $ws.CreateShortcut('{shortcut}'); "
        f"$sc.TargetPath = '{target}'; "
        f"$sc.WorkingDirectory = '{INSTALL_DIR}'; "
        f"$sc.IconLocation = '{target}'; "
        "$sc.Description = 'UKL 런처'; $sc.Save()"
    )
    subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script], check=False, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))


def install():
    payload = resource_root()
    launcher = payload / "UKL.exe"
    if not launcher.exists():
        raise RuntimeError("설치 파일 내부에서 UKL 런처를 찾지 못했습니다.")
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(launcher, INSTALL_DIR / "UKL.exe")
    config = payload / "launcher_config.json"
    if config.exists() and not (INSTALL_DIR / "launcher_config.json").exists():
        shutil.copy2(config, INSTALL_DIR / "launcher_config.json")
    create_shortcut(INSTALL_DIR / "UKL.exe")
    subprocess.Popen([str(INSTALL_DIR / "UKL.exe")], cwd=str(INSTALL_DIR))


if __name__ == "__main__":
    try:
        install()
    except Exception as error:
        root = tk.Tk(); root.withdraw()
        messagebox.showerror("UKL 설치 실패", str(error))
        root.destroy()
        raise
