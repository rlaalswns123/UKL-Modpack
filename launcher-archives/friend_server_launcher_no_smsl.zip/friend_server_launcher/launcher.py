import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
import threading
import urllib.request
import zipfile
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

APP_NAME = "친구 서버 런처"
ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "launcher_config.json"
MANIFEST_URL = ""

DEFAULT_CONFIG = {
    "manifest_url": "",
    "game_dir": str(ROOT / "MinecraftClient"),
    "prism_path": "",
    "prism_instance": "친구서버",
    "ram_gb": 6,
    "width": 1280,
    "height": 720,
    "fullscreen": False,
    "version": "0.0.0"
}


def load_config():
    data = DEFAULT_CONFIG.copy()
    if CONFIG_PATH.exists():
        try:
            data.update(json.loads(CONFIG_PATH.read_text(encoding="utf-8")))
        except Exception:
            pass
    return data


def save_config(data):
    CONFIG_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def java_candidates():
    paths = []
    env_java = os.environ.get("JAVA_HOME")
    if env_java:
        paths.extend([Path(env_java) / "bin" / "javaw.exe", Path(env_java) / "bin" / "java.exe"])
    roots = [
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Java",
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Eclipse Adoptium",
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Microsoft",
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Amazon Corretto",
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "BellSoft",
    ]
    for root in roots:
        if root.exists():
            for p in root.rglob("javaw.exe"):
                paths.append(p)
            for p in root.rglob("java.exe"):
                paths.append(p)
    seen = set()
    result = []
    for p in paths:
        p = p.resolve()
        if p.exists() and str(p).lower() not in seen:
            seen.add(str(p).lower())
            result.append(p)
    return result


def java_major(path):
    try:
        out = subprocess.check_output([str(path), "-version"], stderr=subprocess.STDOUT, text=True, timeout=5)
        first = out.splitlines()[0]
        import re
        m = re.search(r'"(\d+)', first)
        if m:
            n = int(m.group(1))
            return 8 if n == 1 else n
    except Exception:
        return None
    return None


def choose_java(preferred=None):
    candidates = java_candidates()
    if preferred:
        p = Path(preferred)
        if p.exists():
            return p, java_major(p)
    versions = [(p, java_major(p)) for p in candidates]
    versions = [(p, v) for p, v in versions if v]
    versions.sort(key=lambda x: (x[1] not in (17, 21), x[1]))
    for wanted in (17, 21):
        for p, v in versions:
            if v == wanted:
                return p, v
    return (versions[0] if versions else (None, None))


def safe_extract(zip_path, destination):
    destination = Path(destination).resolve()
    with zipfile.ZipFile(zip_path) as z:
        for member in z.infolist():
            target = (destination / member.filename).resolve()
            if not str(target).startswith(str(destination)):
                raise RuntimeError("안전하지 않은 업데이트 파일이 포함되어 있습니다.")
        z.extractall(destination)


class Launcher(tk.Tk):
    def __init__(self):
        super().__init__()
        self.config_data = load_config()
        self.title("친구 서버 런처")
        self.geometry("960x560")
        self.minsize(800, 480)
        self.configure(bg="#15202b")
        self.status_var = tk.StringVar(value="준비되었습니다.")
        self.version_var = tk.StringVar(value=f"클라이언트 {self.config_data.get('version', '0.0.0')}")
        self.build_ui()

    def build_ui(self):
        top = tk.Frame(self, bg="#0d141b", height=66)
        top.pack(fill="x")
        tk.Label(top, text="친구 서버", font=("Segoe UI", 22, "bold"), fg="white", bg="#0d141b").pack(side="left", padx=22, pady=14)
        tk.Label(top, text="친구 서버 런처", font=("Segoe UI", 12), fg="#a9c7dc", bg="#0d141b").pack(side="left")
        tk.Label(top, textvariable=self.version_var, fg="#9bb2c3", bg="#0d141b").pack(side="right", padx=22)

        body = tk.Frame(self, bg="#15202b")
        body.pack(fill="both", expand=True, padx=28, pady=24)
        tk.Label(body, text="Minecraft 친구 서버", font=("Segoe UI", 28, "bold"), fg="white", bg="#15202b").pack(anchor="w")
        tk.Label(body, text="실행 전에 최신 모드와 설정을 확인합니다.", font=("Segoe UI", 12), fg="#b7c6d1", bg="#15202b").pack(anchor="w", pady=(4, 22))

        card = tk.Frame(body, bg="#213442", padx=20, pady=18)
        card.pack(fill="x")
        self.java_label = tk.Label(card, text="Java 검색 중...", font=("Segoe UI", 11), fg="#d7e8f5", bg="#213442")
        self.java_label.pack(anchor="w")
        self.ram_label = tk.Label(card, text=f"RAM: {self.config_data.get('ram_gb', 6)}GB", fg="#b7c6d1", bg="#213442")
        self.ram_label.pack(anchor="w", pady=(8, 0))
        self.update_label = tk.Label(card, text="업데이트 상태: 확인 전", fg="#b7c6d1", bg="#213442")
        self.update_label.pack(anchor="w", pady=(4, 0))

        buttons = tk.Frame(body, bg="#15202b")
        buttons.pack(anchor="w", pady=26)
        self.start_btn = tk.Button(buttons, text="게임 시작", command=self.start_game, width=18, height=2, bg="#3c91d8", fg="white", activebackground="#5eafe9", relief="flat", font=("Segoe UI", 12, "bold"))
        self.start_btn.pack(side="left", padx=(0, 10))
        tk.Button(buttons, text="업데이트 확인", command=self.check_update_thread, width=16, height=2, bg="#344c5d", fg="white", relief="flat").pack(side="left", padx=10)
        tk.Button(buttons, text="설정", command=self.open_settings, width=12, height=2, bg="#344c5d", fg="white", relief="flat").pack(side="left", padx=10)

        tk.Label(body, textvariable=self.status_var, fg="#9fc5dc", bg="#15202b", anchor="w").pack(fill="x", side="bottom")
        self.after(200, self.detect_java)

    def detect_java(self):
        p, v = choose_java()
        if p:
            self.java_label.config(text=f"Java {v} 발견: {p}")
            self.config_data["detected_java"] = str(p)
        else:
            self.java_label.config(text="Java 17 또는 Java 21을 찾지 못했습니다.")
        save_config(self.config_data)

    def check_update_thread(self):
        threading.Thread(target=self.check_update, daemon=True).start()

    def check_update(self):
        url = self.config_data.get("manifest_url", "").strip()
        if not url:
            self.after(0, lambda: self.status_var.set("업데이트 주소가 설정되지 않았습니다. 설정에서 manifest URL을 입력하세요."))
            return
        try:
            self.after(0, lambda: self.update_label.config(text="업데이트 상태: 확인 중..."))
            with urllib.request.urlopen(url, timeout=15) as r:
                manifest = json.loads(r.read().decode("utf-8"))
            latest = str(manifest.get("version", "0.0.0"))
            current = str(self.config_data.get("version", "0.0.0"))
            if latest == current:
                self.after(0, lambda: self.update_label.config(text=f"업데이트 상태: 최신 버전 ({latest})"))
                return
            download = manifest.get("download")
            if not download:
                raise RuntimeError("manifest에 download 주소가 없습니다.")
            game_dir = Path(self.config_data["game_dir"])
            game_dir.mkdir(parents=True, exist_ok=True)
            with tempfile.TemporaryDirectory() as td:
                zip_path = Path(td) / "client-update.zip"
                self.after(0, lambda: self.status_var.set(f"업데이트 다운로드 중: {current} → {latest}"))
                urllib.request.urlretrieve(download, zip_path)
                safe_extract(zip_path, game_dir)
            self.config_data["version"] = latest
            save_config(self.config_data)
            self.after(0, lambda: self.version_var.set(f"클라이언트 {latest}"))
            self.after(0, lambda: self.update_label.config(text=f"업데이트 상태: 업데이트 완료 ({latest})"))
            self.after(0, lambda: self.status_var.set("업데이트가 완료되었습니다."))
        except Exception as e:
            self.after(0, lambda: self.update_label.config(text="업데이트 상태: 실패"))
            self.after(0, lambda: self.status_var.set(f"업데이트 실패: {e}"))

    def start_game(self):
        self.start_btn.config(state="disabled")
        def work():
            if self.config_data.get("manifest_url", "").strip():
                self.check_update()
            try:
                prism = self.config_data.get("prism_path", "").strip()
                instance = self.config_data.get("prism_instance", "친구서버")
                if not prism or not Path(prism).exists():
                    raise RuntimeError("Prism Launcher 경로가 설정되지 않았습니다. 설정에서 PrismLauncher.exe를 선택하세요.")
                subprocess.Popen([prism, "--launch", instance])
                self.after(0, self.destroy)
            except Exception as e:
                self.after(0, lambda: messagebox.showerror("게임 실행 실패", str(e)))
                self.after(0, lambda: self.start_btn.config(state="normal"))
        threading.Thread(target=work, daemon=True).start()

    def open_settings(self):
        win = tk.Toplevel(self)
        win.title("런처 설정")
        win.geometry("600x480")
        win.configure(bg="#182630")
        fields = {}
        rows = [("업데이트 manifest URL", "manifest_url"), ("게임 폴더", "game_dir"), ("Prism Launcher 경로", "prism_path"), ("Prism 인스턴스 이름", "prism_instance")]
        for i, (label, key) in enumerate(rows):
            tk.Label(win, text=label, fg="white", bg="#182630").grid(row=i, column=0, sticky="w", padx=18, pady=10)
            var = tk.StringVar(value=str(self.config_data.get(key, "")))
            fields[key] = var
            tk.Entry(win, textvariable=var, width=48).grid(row=i, column=1, padx=8, pady=10)
            if key in ("game_dir", "prism_path"):
                tk.Button(win, text="찾기", command=lambda k=key, v=var: self.pick_path(k, v)).grid(row=i, column=2, padx=8)
        row = len(rows)
        tk.Label(win, text="RAM (GB)", fg="white", bg="#182630").grid(row=row, column=0, sticky="w", padx=18, pady=10)
        ram = tk.IntVar(value=int(self.config_data.get("ram_gb", 6)))
        fields["ram_gb"] = ram
        ttk.Spinbox(win, from_=2, to=32, textvariable=ram, width=8).grid(row=row, column=1, sticky="w", padx=8)
        row += 1
        tk.Label(win, text="화면 너비 × 높이", fg="white", bg="#182630").grid(row=row, column=0, sticky="w", padx=18, pady=10)
        width = tk.IntVar(value=int(self.config_data.get("width", 1280))); height = tk.IntVar(value=int(self.config_data.get("height", 720)))
        fields["width"] = width; fields["height"] = height
        tk.Entry(win, textvariable=width, width=8).grid(row=row, column=1, sticky="w", padx=8)
        tk.Entry(win, textvariable=height, width=8).grid(row=row, column=1, padx=(110, 8), sticky="w")
        def save():
            for k, v in fields.items(): self.config_data[k] = v.get()
            save_config(self.config_data)
            self.ram_label.config(text=f"RAM: {self.config_data['ram_gb']}GB")
            win.destroy()
            self.status_var.set("설정이 저장되었습니다.")
        tk.Button(win, text="저장", command=save, bg="#3c91d8", fg="white", relief="flat", width=15).grid(row=row+2, column=1, pady=26)

    def pick_path(self, key, var):
        if key == "game_dir": p = filedialog.askdirectory()
        else: p = filedialog.askopenfilename(filetypes=[("실행 파일", "*.exe"), ("모든 파일", "*.*")])
        if p: var.set(p)


if __name__ == "__main__":
    Launcher().mainloop()
