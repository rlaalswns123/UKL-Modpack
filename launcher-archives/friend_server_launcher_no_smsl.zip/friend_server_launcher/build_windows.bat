@echo off
setlocal
python -m pip install --upgrade pyinstaller
python -m PyInstaller --noconfirm --clean --onefile --windowed --name FriendServerLauncher launcher.py
copy launcher_config.json dist\launcher_config.json
if exist dist\FriendServerLauncher.exe (
  echo Build complete: dist\FriendServerLauncher.exe
) else (
  echo Build failed.
  exit /b 1
)
pause
