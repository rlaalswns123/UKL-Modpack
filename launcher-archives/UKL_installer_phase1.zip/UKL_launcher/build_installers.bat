@echo off
setlocal

python -m pip install --upgrade pyinstaller
if errorlevel 1 exit /b 1

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist payload rmdir /s /q payload
mkdir payload

 echo [1/2] UKL 런처 빌드 중...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name UKL launcher_v2.py
if errorlevel 1 exit /b 1

copy dist\UKL.exe payload\UKL.exe >nul
copy launcher_config.json payload\launcher_config.json >nul

 echo [2/2] UKL_Setup.exe 빌드 중...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name UKL_Setup --add-binary "payload\UKL.exe;payload" --add-data "payload\launcher_config.json;payload" installer.py
if errorlevel 1 exit /b 1

echo.
echo Build complete:
echo   dist\UKL.exe
 echo  dist\UKL_Setup.exe
echo.
echo 친구들에게 배포할 파일: dist\UKL_Setup.exe
pause
