import json
import os
import re
import subprocess
import sys
import webbrowser
import tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox, filedialog

ROOT = Path(__file__).resolve().parent
# PyInstaller --onefile 실행 시 __file__은 임시 폴더를 가리킬 수 있으므로,
# 사용자 설정은 항상 영구적인 Windows AppData 위치에 저장합니다.
if getattr(sys, "frozen", False):
    CONFIG_DIR = Path(os.environ.get("APPDATA", Path.home())) / "UKL"
else:
    CONFIG_DIR = ROOT
CONFIG_DIR.mkdir(parents=True, exist_ok=True)
CONFIG_PATH = CONFIG_DIR / "launcher_config.json"
DEFAULT_CONFIG = {"manifest_url": "", "game_dir": str(CONFIG_DIR / "MinecraftClient"), "ram_gb": 6, "width": 1280, "height": 720, "minecraft_version": "1.20.1", "loader": "미정", "version": "0.0.0", "setup_complete": False, "selected_java": "", "microsoft_client_id": "", "microsoft_signed_in": False}


def load_config():
    data = DEFAULT_CONFIG.copy()
    if CONFIG_PATH.exists():
        try:
            data.update(json.loads(CONFIG_PATH.read_text(encoding="utf-8")))
        except Exception:
            pass
    return data


def save_config(data):
    CONFIG_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def find_java():
    roots = [Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / name for name in ("Java", "Eclipse Adoptium", "Microsoft", "Amazon Corretto", "BellSoft")]
    env = os.environ.get("JAVA_HOME")
    paths = [Path(env) / "bin" / "javaw.exe"] if env else []
    for root in roots:
        if root.exists():
            paths += list(root.rglob("javaw.exe")) + list(root.rglob("java.exe"))
    found = {}
    for path in paths:
        try:
            out = subprocess.check_output([str(path), "-version"], stderr=subprocess.STDOUT, text=True, timeout=5)
            match = re.search(r'"(\d+)', out.splitlines()[0])
            major = int(match.group(1)) if match else None
            major = 8 if major == 1 else major
            if major in (17, 21):
                found.setdefault(major, path.resolve())
        except Exception:
            continue
    return sorted(found.items())


class Wizard(tk.Toplevel):
    def __init__(self, parent, config, done):
        super().__init__(parent)
        self.parent, self.config, self.done, self.page = parent, config, done, 0
        self.title("UKL 처음 설정")
        self.geometry("620x430")
        self.resizable(False, False)
        self.configure(bg="#182630")
        self.protocol("WM_DELETE_WINDOW", self.destroy)
        self.grab_set()
        self.render()

    def render(self):
        for child in self.winfo_children(): child.destroy()
        if self.page == 0:
            self.heading("UKL에 오신 것을 환영합니다", "처음 한 번만 기본 설정을 진행합니다. 이후에는 UKL에서 게임 준비와 실행을 관리합니다.")
            self.text("현재 단계에서는 독립형 화면, 설정 저장, Java 확인까지 구현되어 있습니다. Microsoft 로그인과 Minecraft 직접 실행은 다음 단계에서 연결합니다.")
            self.nav(False, "시작하기")
        elif self.page == 1:
            self.heading("Java 환경 확인", "Java 17과 21을 자동으로 검색합니다. Minecraft 1.20.1은 Java 17을 우선 사용합니다.")
            found = find_java()
            self.config["selected_java"] = str(next((p for v, p in found if v == 17), found[0][1] if found else ""))
            if found:
                for version, path in found: self.text(f"✓ Java {version}: {path}", "#bde8c6")
            else: self.text("Java 17 또는 Java 21을 찾지 못했습니다. 나중에 설정에서 다시 검색할 수 있습니다.", "#ffd0a8")
            self.nav(True)
        elif self.page == 2:
            self.heading("게임 기본 설정", "친구의 컴퓨터 사양에 맞춰 기본 RAM과 화면 크기를 설정합니다.")
            box = tk.Frame(self, bg="#182630"); box.pack(anchor="w", padx=42, pady=28)
            tk.Label(box, text="RAM 할당량 (GB)", fg="white", bg="#182630").grid(row=0, column=0, sticky="w", pady=10)
            self.ram = tk.IntVar(value=int(self.config.get("ram_gb", 6))); ttk.Spinbox(box, from_=2, to=32, textvariable=self.ram, width=8).grid(row=0, column=1, padx=28)
            tk.Label(box, text="화면 크기", fg="white", bg="#182630").grid(row=1, column=0, sticky="w", pady=10)
            self.width = tk.IntVar(value=int(self.config.get("width", 1280))); self.height = tk.IntVar(value=int(self.config.get("height", 720)))
            tk.Entry(box, textvariable=self.width, width=8).grid(row=1, column=1, sticky="w", padx=28); tk.Entry(box, textvariable=self.height, width=8).grid(row=1, column=1, sticky="e")
            self.nav(True)
        else:
            self.heading("설정 완료", "기본 설정이 저장되었습니다. 다음 단계에서 Microsoft 로그인, 모드팩 업데이트, Minecraft 직접 실행을 연결합니다.")
            self.text("다음부터는 UKL을 실행하면 이 화면 대신 메인 런처가 표시됩니다.", "#bde8c6")
            self.nav(False, "완료")

    def heading(self, title, desc):
        tk.Label(self, text=title, font=("Segoe UI", 22, "bold"), fg="white", bg="#182630").pack(anchor="w", padx=32, pady=(28, 6))
        tk.Label(self, text=desc, fg="#b8cad6", bg="#182630", wraplength=540, justify="left").pack(anchor="w", padx=32)

    def text(self, value, color="#d7e8f5"):
        tk.Label(self, text=value, fg=color, bg="#182630", wraplength=540, justify="left").pack(anchor="w", padx=42, pady=12)

    def nav(self, back, next_text="다음"):
        bar = tk.Frame(self, bg="#182630"); bar.pack(side="bottom", fill="x", padx=32, pady=24)
        if back: tk.Button(bar, text="이전", command=self.back, width=12, bg="#344c5d", fg="white", relief="flat").pack(side="left")
        tk.Button(bar, text=next_text, command=self.next, width=12, bg="#3c91d8", fg="white", relief="flat").pack(side="right")

    def next(self):
        if self.page == 2:
            self.config.update(ram_gb=int(self.ram.get()), width=int(self.width.get()), height=int(self.height.get()))
        if self.page < 3: self.page += 1; self.render()
        else:
            self.config["setup_complete"] = True; save_config(self.config); self.destroy(); self.done()

    def back(self):
        if self.page > 0: self.page -= 1; self.render()


class Launcher(tk.Tk):
    def __init__(self):
        super().__init__(); self.config_data = load_config(); self.title("UKL"); self.geometry("960x560"); self.minsize(800, 480); self.configure(bg="#15202b")
        self.status = tk.StringVar(value="준비되었습니다."); self.version = tk.StringVar(value=f"클라이언트 {self.config_data.get('version', '0.0.0')}"); self.build_ui(); self.after(250, self.detect_java)
        if not self.config_data.get("setup_complete"): self.after(350, self.open_wizard)

    def build_ui(self):
        top = tk.Frame(self, bg="#0d141b"); top.pack(fill="x")
        tk.Label(top, text="UKL", font=("Segoe UI", 22, "bold"), fg="white", bg="#0d141b").pack(side="left", padx=22, pady=14); tk.Label(top, text="UKL Launcher", fg="#a9c7dc", bg="#0d141b").pack(side="left"); tk.Label(top, textvariable=self.version, fg="#9bb2c3", bg="#0d141b").pack(side="right", padx=22)
        body = tk.Frame(self, bg="#15202b"); body.pack(fill="both", expand=True, padx=28, pady=24)
        tk.Label(body, text="UKL Minecraft", font=("Segoe UI", 28, "bold"), fg="white", bg="#15202b").pack(anchor="w"); tk.Label(body, text="독립형 런처를 단계별로 준비하고 있습니다.", fg="#b7c6d1", bg="#15202b").pack(anchor="w", pady=(4, 22))
        card = tk.Frame(body, bg="#213442", padx=20, pady=18); card.pack(fill="x")
        self.java_label = tk.Label(card, text="Java 검색 중...", fg="#d7e8f5", bg="#213442"); self.java_label.pack(anchor="w"); self.ram_label = tk.Label(card, text=f"RAM: {self.config_data.get('ram_gb', 6)}GB", fg="#b7c6d1", bg="#213442"); self.ram_label.pack(anchor="w", pady=(8, 0)); tk.Label(card, text="현재 단계: 기본 런처 준비 완료", fg="#b7c6d1", bg="#213442").pack(anchor="w", pady=(4, 0))
        buttons = tk.Frame(body, bg="#15202b"); buttons.pack(anchor="w", pady=26); tk.Button(buttons, text="게임 시작", command=self.start_game, width=18, height=2, bg="#3c91d8", fg="white", relief="flat", font=("Segoe UI", 12, "bold")).pack(side="left"); tk.Button(buttons, text="Microsoft 로그인", command=self.microsoft_login, width=18, height=2, bg="#344c5d", fg="white", relief="flat").pack(side="left", padx=10); tk.Button(buttons, text="설정 마법사", command=self.open_wizard, width=16, height=2, bg="#344c5d", fg="white", relief="flat").pack(side="left", padx=10); tk.Button(buttons, text="설정", command=self.open_settings, width=12, height=2, bg="#344c5d", fg="white", relief="flat").pack(side="left")
        tk.Label(body, textvariable=self.status, fg="#9fc5dc", bg="#15202b", anchor="w").pack(fill="x", side="bottom")

    def detect_java(self):
        found = find_java()
        if found:
            version, path = next(((v, p) for v, p in found if v == 17), found[0]); self.config_data["selected_java"] = str(path); self.java_label.config(text=f"Java {version} 자동 선택: {path}"); save_config(self.config_data)
        else: self.java_label.config(text="Java 17 또는 Java 21을 찾지 못했습니다.")

    def open_wizard(self): Wizard(self, self.config_data, self.wizard_done)
    def wizard_done(self): self.ram_label.config(text=f"RAM: {self.config_data.get('ram_gb', 6)}GB"); self.detect_java(); self.status.set("초기 설정이 저장되었습니다.")
    def start_game(self): messagebox.showinfo("UKL", "현재 단계에서는 기본 런처와 설정 마법사까지 구현되어 있습니다. Minecraft 직접 실행은 다음 단계에서 연결합니다.")

    def microsoft_login(self):
        if not self.config_data.get("microsoft_client_id"):
            messagebox.showinfo("Microsoft 로그인 준비", "먼저 설정에서 Microsoft Client ID를 입력하세요. Client Secret이나 비밀번호는 입력하지 않습니다.")
            self.open_settings()
            return
        messagebox.showinfo("Microsoft 로그인", "2단계 준비가 완료되었습니다. 실제 OAuth 로그인 창과 Minecraft 토큰 교환은 다음 구현 단계에서 연결합니다.")

    def open_settings(self):
        win = tk.Toplevel(self); win.title("UKL 설정"); win.geometry("600x330"); win.configure(bg="#182630"); fields = {}
        for i, (label, key) in enumerate((("업데이트 manifest URL", "manifest_url"), ("게임 폴더", "game_dir"), ("Minecraft 버전", "minecraft_version"), ("로더", "loader"), ("Microsoft Client ID", "microsoft_client_id"))):
            tk.Label(win, text=label, fg="white", bg="#182630").grid(row=i, column=0, sticky="w", padx=18, pady=10); var = tk.StringVar(value=str(self.config_data.get(key, ""))); fields[key] = var; tk.Entry(win, textvariable=var, width=42).grid(row=i, column=1, padx=8, pady=10)
            if key == "game_dir": tk.Button(win, text="찾기", command=lambda v=var: v.set(filedialog.askdirectory() or v.get())).grid(row=i, column=2)
        def save():
            for key, var in fields.items(): self.config_data[key] = var.get()
            save_config(self.config_data); win.destroy(); self.status.set("설정이 저장되었습니다.")
        tk.Button(win, text="Client ID 발급 안내", command=lambda: webbrowser.open("https://entra.microsoft.com/"), bg="#344c5d", fg="white", relief="flat").grid(row=5, column=0, pady=24)
        tk.Button(win, text="저장", command=save, bg="#3c91d8", fg="white", relief="flat", width=15).grid(row=5, column=1, pady=24)


if __name__ == "__main__": Launcher().mainloop()
