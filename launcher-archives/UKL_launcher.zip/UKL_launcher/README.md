# UKL 런처 1차 버전

Java 17·21 자동 탐색, RAM 설정, 화면 크기 설정, 모드팩 자동 업데이트, Prism Launcher 실행을 포함한 Windows 런처 기본 프로젝트입니다.

## 현재 포함된 기능

- Java 17·21 자동 탐색
- Java 설치 경로 표시
- RAM 할당량 설정 저장
- 화면 너비·높이 설정 저장
- 게임 폴더 설정
- 업데이트 manifest URL 확인
- ZIP 형태 모드팩 업데이트
- `mods`, `config`, `defaultconfigs`를 포함한 업데이트 ZIP 적용
- 설정과 버전 파일 보존
- Prism Launcher를 통한 게임 실행

## 중요한 제한

이 1차 버전은 Microsoft 계정 인증을 직접 구현하지 않습니다. 친구의 계정 비밀번호를 받지 않고 안전하게 사용하기 위해, Prism Launcher에서 Microsoft 로그인을 한 번 완료한 뒤 런처가 Prism 인스턴스를 실행하도록 구성했습니다. 공식 런처 없이 직접 게임을 실행하는 Microsoft 인증 모듈은 별도 단계로 추가해야 합니다.

## Windows에서 빌드하기

Windows PC에서 Python 3.11 이상을 설치한 뒤 이 폴더에서 `build_windows.bat`를 실행합니다. 결과 파일은 `dist\UKL.exe`입니다.

## 첫 설정

1. Prism Launcher에서 `친구서버`라는 인스턴스를 만들고 Forge/Fabric과 모드를 설치합니다.
2. Prism Launcher에서 Microsoft 계정 로그인을 완료합니다.
3. 런처를 실행하고 **설정**에서 `PrismLauncher.exe` 경로와 인스턴스 이름을 지정합니다.
4. 업데이트를 사용할 경우 `manifest_url`에 온라인 `manifest.json` 주소를 입력합니다.
5. `게임 폴더`는 업데이트 ZIP을 적용할 클라이언트 폴더로 지정합니다.

## 업데이트 파일 구조

manifest 예시:

```json
{
  "version": "1.0.1",
  "minecraft": "1.20.1",
  "loader": "forge",
  "download": "https://example.com/client-1.0.1.zip"
}
```

ZIP 내부는 다음처럼 구성합니다.

```text
mods/
config/
defaultconfigs/
```

런처는 업데이트 ZIP을 게임 폴더에 안전하게 압축 해제합니다. `saves`, `screenshots`, `options.txt`, `servers.dat`는 ZIP에 넣지 않아 기존 사용자 데이터를 보존하세요.

## 권장 배포 구조

```text
UKL/
├─ UKL.exe
├─ launcher_config.json
└─ MinecraftClient/
   ├─ mods/
   ├─ config/
   └─ defaultconfigs/
```

## 참고

Prism Launcher의 실제 실행 인자나 설치 위치는 버전에 따라 다를 수 있습니다. 실행이 되지 않으면 설정에서 Prism Launcher 경로와 인스턴스 이름을 확인하세요.

## 나중에 추가할 기능: 런처 이미지

배경, UKL 로고, 프로필 아이콘, 디스코드 아이콘 등의 이미지는 추후 `assets` 폴더에 넣고 런처 UI에 연결할 수 있습니다. Windows 빌드 시 PyInstaller의 `--add-data "assets;assets"` 옵션을 사용하며, 실행 파일 내부의 이미지 경로를 처리하는 리소스 경로 코드가 필요합니다.
