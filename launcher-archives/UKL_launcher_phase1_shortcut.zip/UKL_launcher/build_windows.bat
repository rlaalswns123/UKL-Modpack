@echo off
setlocal
python -m pip install --upgrade pyinstaller
python -m PyInstaller --noconfirm --clean --onefile --windowed --name UKL launcher_v2.py
copy launcher_config.json dist\launcher_config.json
if exist dist\UKL.exe (
  echo Build complete: dist\UKL.exe
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $sc = $ws.CreateShortcut([Environment]::GetFolderPath('Desktop') + '\UKL.lnk'); $sc.TargetPath = (Resolve-Path 'dist\UKL.exe').Path; $sc.WorkingDirectory = (Resolve-Path 'dist').Path; $sc.IconLocation = (Resolve-Path 'dist\UKL.exe').Path; $sc.Description = 'UKL 런처'; $sc.Save()"
  echo Desktop shortcut created: UKL
) else (
  echo Build failed.
  exit /b 1
)
pause
