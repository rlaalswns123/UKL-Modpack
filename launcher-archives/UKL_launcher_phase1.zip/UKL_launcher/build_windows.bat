@echo off
setlocal
python -m pip install --upgrade pyinstaller
python -m PyInstaller --noconfirm --clean --onefile --windowed --name UKL launcher_v2.py
copy launcher_config.json dist\launcher_config.json
if exist dist\UKL.exe (
  echo Build complete: dist\UKL.exe
) else (
  echo Build failed.
  exit /b 1
)
pause
