@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title UKL Friend Builder

echo ========================================
echo UKL Friend launcher build
echo ========================================

echo.
where python >nul 2>&1
if errorlevel 1 goto NO_PYTHON
python --version
if errorlevel 1 goto NO_PYTHON

if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist payload rmdir /s /q payload
mkdir payload

echo.
set "FRIEND_CLIENT_ID="
set /p "FRIEND_CLIENT_ID=Azure Microsoft Client ID를 입력하세요 (Client Secret은 입력하지 마세요): "
>friend_build_settings.py echo MICROSOFT_CLIENT_ID = "%FRIEND_CLIENT_ID%"

echo [1/3] Building friend launcher...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name UKL_Friend launcher_friend.py
if errorlevel 1 goto FAIL
if not exist dist\UKL_Friend.exe goto FAIL
copy /y dist\UKL_Friend.exe payload\UKL.exe >nul
copy /y launcher_config.json payload\launcher_config.json >nul

echo [2/3] Building friend setup...
python -m PyInstaller --noconfirm --clean --onefile --windowed --name UKL_Friend_Setup --add-binary "payload\UKL.exe;payload" --add-data "payload\launcher_config.json;payload" installer_friend.py
if errorlevel 1 goto FAIL
if not exist dist\UKL_Friend_Setup.exe goto FAIL

echo [3/3] BUILD COMPLETE
echo.
echo Friend installer:
echo %CD%\dist\UKL_Friend_Setup.exe
goto DONE

:NO_PYTHON
echo ERROR: Python was not found.
goto FAIL

:FAIL
echo.
echo BUILD FAILED. Read the error messages above.

:DONE
echo.
pause
endlocal
