@echo off
setlocal

title Minecraft Forge Server
cd /d D:\MinecraftServer

if not exist run.bat (
    echo [오류] D:\MinecraftServer\run.bat 파일이 없습니다.
    echo 먼저 Forge 서버를 D:\MinecraftServer에 설치하세요.
    pause
    exit /b 1
)

call run.bat nogui

pause
endlocal
