Minecraft Forge D드라이브 서버 기본 파일
========================================

1. D:\MinecraftServer 폴더를 만듭니다.
2. 이 폴더의 파일을 D:\MinecraftServer 안에 복사합니다.
3. Forge Installer를 D:\MinecraftServer에 넣습니다.
4. 해당 폴더에서 명령 프롬프트를 열고 다음을 실행합니다.

   java -jar forge-버전-installer.jar --installServer

   예시:
   java -jar forge-1.20.1-47.3.0-installer.jar --installServer

5. 설치가 끝난 뒤 run.bat를 한 번 실행합니다.
6. eula.txt가 생성되면 내용을 확인한 뒤 eula=false를 eula=true로 변경합니다.
7. user_jvm_args.txt에서 서버 메모리를 확인합니다.
   현재 기본값: 시작 8GB, 최대 12GB
8. start-server.bat를 실행해 서버를 시작합니다.

중요:
- Forge 버전에 따라 Java 17 또는 Java 21이 필요합니다.
- 실제 Forge 설치 후 생성되는 run.bat를 사용하세요.
- server.properties는 서버가 한 번 실행된 뒤 생성된 파일을 우선 사용하세요.
- 서버 종료는 콘솔에 stop을 입력하세요. 창을 강제 종료하지 마세요.
- D:\MinecraftServer\mods 폴더에 서버용 모드를 넣으세요.
- 클라이언트와 서버의 모드 및 모드 버전이 일치해야 합니다.
